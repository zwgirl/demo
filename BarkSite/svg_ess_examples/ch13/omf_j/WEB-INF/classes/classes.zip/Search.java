/* $Id: RequestParamExample.java,v 1.1.1.1 1999/10/09 00:20:00 duncan Exp $
 *
 */

import java.io.*;
import java.text.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.apache.xalan.xslt.*;

public class Search extends HttpServlet {

    ResourceBundle rb = ResourceBundle.getBundle("SearchFileStrings");

	/*
	 * Utility routine to convert strings to
	 * integers; if not convertible, return zero.
	 * This function avoids having lots of try/catch
	 * blocks cluttering up the code
	 */
	private int cvtInt( String str )
	{
		int	n;
		try
		{
			n = Integer.parseInt( str );
		}
		catch (Exception e)
		{
			n = 0;
		}
		return n;
	}
			
	/*
	 * Write the standard end-of-html-file tags
	 *
	 */
	private void writeFooter( PrintWriter out )
	{
		out.println("</body>");
		out.println("</html>");
	}

	/*
	 * Change:
	 *	& to &amp;
	 *  < to &lt;
	 *  > to &gt;
	 *
	 */
	private String protectEntities( String str )
	{
		int len;
		int i = 0;
		StringBuffer sb = new StringBuffer( str );
		while ( i < sb.length() )
		{
			if (sb.charAt(i) == '&')
			{
				sb.replace( i, i+1, "&amp;");
				i += 4;
			}
			else if (sb.charAt(i) == '<')
			{
				sb.replace( i, i+1, "&lt;");
				i += 3;
			}
			else if (sb.charAt(i) == '>')
			{
				sb.replace( i, i+1, "&gt;");
				i += 3;
			}
			i++;
		}
		return sb.toString( );
	}

	/*
	 * Assemble an XSLT test expression from the 
	 * text-and-menu form
	 */
	private String assembleExpression( HttpServletRequest request )
	{
        String sMinWidth = request.getParameter("minWidth").trim( );
        String sMaxWidth = request.getParameter("maxWidth").trim( );
        String sMinHeight = request.getParameter("minHeight").trim( );
        String sMaxHeight = request.getParameter("maxHeight").trim( );
		String containStr = request.getParameter("containStr").trim( );
		String andOr1 = request.getParameter("and_or1");
		String andOr2 = request.getParameter("and_or2");
		boolean needOperator = false;
		boolean needSubOperator = false;

		// open parenthesis in ifString is used to group width/height
		String ifString = "<xsl:if test=\"";

		/*
		 * Create parenthesized expression of form
		 *   (width &gt;= 100 and width &lt;=200)
		 */
		if (!(sMinWidth.equals("") && sMaxWidth.equals("")))
		{
			ifString += "(";	// open grouping for width/height
			needOperator = true;
			ifString += "(";
			if (!sMinWidth.equals(""))
			{
				ifString += "width &gt;= " + sMinWidth;
				needSubOperator = true;
			}
			if (!sMaxWidth.equals(""))
			{
				if (needSubOperator) { ifString += " and  "; }
				ifString += "width &lt;= " + sMaxWidth;
			}
			ifString += ")";
		}

		/*
		 * Create parenthesized expression of form
		 *   (height &gt;= 100 and height &lt;=200)
		 */
		if (!(sMinHeight.equals("") && sMaxHeight.equals("")))
		{
			if (needOperator)
			{
				ifString += request.getParameter( "and_or1" );
			}
			else
			{
				ifString += "(";
			}
			needOperator = true;
			needSubOperator = false;
			ifString += "(";
			if (!sMinHeight.equals(""))
			{
				ifString += "height &gt;= " + sMinHeight;
				needSubOperator = true;
			}
			if (!sMaxHeight.equals(""))
			{
				if (needSubOperator) { ifString += " and  "; }
				ifString += "height &lt;= " + sMaxHeight;
			}
			ifString += ")";
		}
		if (needOperator)
		{
			ifString += ")"; // closing grouping parenthesis
		}


		/*
		 * Finally, create expression of form
		 *  contains( @name, "str" )
		 */
		if ( !containStr.equals("") )
		{
			if (needOperator)
			{
				ifString += request.getParameter( "and_or2" );
			}
			ifString += "contains(@name, '" + containStr + "')";
		}

		if (!request.getParameter( "imgtype" ).equals("any"))
		{
			ifString += " and type=\'" + request.getParameter( "imgtype" )
				+ "'";
		}
		ifString += "\">";
		return ifString;
	}

    public void doGet(HttpServletRequest request,
                      HttpServletResponse response)
        throws IOException, ServletException
    {
		String	searchStr;
		String	serverString;
		XSLTInputSource	xmlSource;
		XSLTInputSource xslSource;
		XSLTResultTarget transformOutput;
		XSLTProcessor processor;

		String ifString;
		String xslString;

		long startTime;
		long startProcessTime;
		long endProcessTime;

		BufferedReader xslFile;
		StringReader reader;

		startTime = new Date().getTime();

		serverString = request.getParameter("server");

        response.setContentType("text/html");

        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<body>");
        out.println("<head>");
        out.println("<title> Search Results </title>");
        out.println("</head>");
        out.println("<body bgcolor=\"white\">");

		try 
		{
			processor = XSLTProcessorFactory.getProcessor( );
		}
		catch (Exception e)
		{
			out.println("<p>Unable to create processor</p>");
			writeFooter( out );
			return;
		}

        String title = rb.getString("xmlFileName");

		xmlSource = new XSLTInputSource( title );
		if (xmlSource == null)
		{
			out.println("<p>Cannot open input file</p>");
			writeFooter( out );
			return;
		}

		if (request.getParameter("useExpr").equals("true"))
		{
			ifString = request.getParameter( "searchExpr" );
			ifString = protectEntities( ifString );
			ifString = "<xsl:if test=\"" + ifString + "\">";
		}
		else
		{
			ifString = assembleExpression( request );
		}

		/*
		 * open XSL file and substitute variable strings
		 * substitution works as follows:
		 *
		 *   if a line in the file contains
		 *      #0   replace the #0 with the "if" string
		 *      #1   replace the #1 with the server name string
		 *
		 * In the best of all possible worlds, we'd put the
		 * substitution strings in an array so that we could
		 * have up to nine substitution strings without needing
		 * a multi-way if (or, in this case, the ?: operator)
		 *
		 * This is left as an exercise for the reader [grin]
		 */
		xslString = "";
        title = rb.getString("xslTemplateFileName");

		try
		{
			xslFile = new BufferedReader(new FileReader(title));
		}
		catch (Exception e)
		{
			out.println("<p>Error opening the XSL file</p>");
			writeFooter( out );
			return;
		}

		try {
			String data;
			int pos;

			while ( (data = xslFile.readLine()) != null )
			{
				if ((pos=data.indexOf( '#' )) >= 0 )
				{
					data = data.substring( 0, pos ) +	
					((data.charAt(pos+1) == '0') ?
						ifString :
						serverString ) +
						data.substring( pos+2 );
				}
				xslString += data + "\n";
			}
		}
		catch (Exception e)
		{
			out.println("<p>Error reading the XSL file <br> "+
				e.getMessage() + "</p>");
			writeFooter( out );
			return;
		}

		reader = new StringReader( xslString );
		
		if (reader == null)
		{
			out.println("<p>Cannot create XSL memory area.</p>");
			writeFooter( out );
			return;
		}

		xslSource = new XSLTInputSource( reader );
		transformOutput = new XSLTResultTarget( out );

		out.println( "<p>Your XSLT expression:</p><blockquote>" );
		out.println("<tt>" + protectEntities(ifString) + "</tt>" );
		out.println("</blockquote>");

		startProcessTime = new Date().getTime();
		endProcessTime = startProcessTime;
	
		try {
			processor.process( xmlSource, xslSource, transformOutput );
		}
		catch (Exception e )
		{
			out.println("<p>Cannot transform</p>");
			out.println("<pre>" + e.getMessage() + "</pre>" );
		}
		endProcessTime = new Date().getTime( );

		NumberFormat nf = NumberFormat.getInstance( );
		nf.setMaximumFractionDigits( 3 );

		out.println( "<p>Setup time: " +
			nf.format( ((long) (startProcessTime - startTime)) / 1000.0 ) + 
			" seconds.<br />");
		out.println("Processing time: " +
			nf.format( (endProcessTime - startProcessTime) / 1000.0 ) +
			" seconds.</p>");
        out.println("</body>");
        out.println("</html>");
    }

    public void doPost(HttpServletRequest request,
                      HttpServletResponse response)
        throws IOException, ServletException
    {
        doGet(request, response);
    }

}
