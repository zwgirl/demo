import java.io.*;

public class SpecialReader extends BufferedReader {

	String substituteString[];

	public SpecialReader( Reader in )
	{
		super( in );
		substituteString = new String[10];
	}

	public SpecialReader( Reader in, int nStrings )
	{
		super( in );
		substituteString = new String[nStrings];
	}

	public String readLine( ) throws IOException {
		String	temp;
		int		n;
		temp = super.readLine( );
		if (temp.charAt(0) == '#')
		{
			temp = temp.substring( 1 );
			try {
				n = Integer.parseInt( temp );
			}
			catch (Exception e )
			{
				n = 0;
			}
			temp = substituteString[n];
		}
		System.err.println( temp );
		return temp;
	}

	public void setSubstitute( int n, String s )
	{
		if (n >= 0 && n < substituteString.length )
		{
			substituteString[n] = s;
		}
	}


}
